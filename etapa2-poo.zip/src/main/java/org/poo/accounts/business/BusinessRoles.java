package org.poo.accounts.business;

public enum BusinessRoles {
    OWNER,
    MANAGER,
    EMPLOYEE
}
